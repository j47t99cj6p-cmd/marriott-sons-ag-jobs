# Marriott & Sons AG Jobs
iPhone-friendly web app. Upload `index.html`, `app.js`, and `manifest.webmanifest` to the GitHub repository root, then enable GitHub Pages from Settings > Pages using the `main` branch and `/ (root)` folder.
